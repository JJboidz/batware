@echo off

if not "%1"=="min" start "" /min cmd /c "%~f0" min & exit

start "" powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command ^
Add-Type -AssemblyName System.Windows.Forms; ^
Add-Type -AssemblyName System.Drawing; ^
$form = New-Object Windows.Forms.Form; ^
$form.Text = "system"; ^
$form.BackColor = "Black"; ^
$form.ForeColor = "Red"; ^
$form.Width = 250; ^
$form.Height = 150; ^
$form.FormBorderStyle = "None"; ^
$form.StartPosition = "Manual"; ^
$x=100; $y=100; ^
$dx=8; $dy=6; ^
$form.Show(); ^
while($true){ ^
    $x += $dx; ^
    $y += $dy; ^
    if($x -lt 0 -or $x -gt [System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Width - 250){$dx=-$dx}; ^
    if($y -lt 0 -or $y -gt [System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Height - 150){$dy=-$dy}; ^
    $form.Location = New-Object System.Drawing.Point($x,$y); ^
    Start-Sleep -Milliseconds 15; ^
}