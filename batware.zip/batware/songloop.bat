@echo off

if not "%1"=="min" start "" /min cmd /c "%~f0" min & exit

@echo off
set "file=%~dp0song.webm"

:loop
start "" wmplayer "%file%"

:watch
timeout /t 1 >nul

tasklist | find /i "wmplayer.exe" >nul
if errorlevel 1 goto loop

goto watch